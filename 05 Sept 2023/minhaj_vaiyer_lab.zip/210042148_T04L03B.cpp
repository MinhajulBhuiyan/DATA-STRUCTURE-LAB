#include <iostream>
#include <stack>
#include <vector>

using namespace std;

int main()
{
    while (true)
    {
        vector<int> ranks;
        int rank;

        while (true)
        {
            cin >> rank;
            if (rank == -1)
            {
                break;
            }
            ranks.push_back(rank);
        }

        if (ranks.empty())
        {
            break;
        }

        int n = ranks.size();
        vector<int> nextSenior(n, -1);

        stack<int> s;

        for (int i = 0; i < n; i++)
        {
            while (!s.empty() && ranks[i] > ranks[s.top()])
            {
                nextSenior[s.top()] = ranks[i];
                s.pop();
            }
            s.push(i);
        }

        for (int i = 0; i < n; i++)
        {
            if (nextSenior[i] != -1)
            {
                cout << nextSenior[i];
            }
            else
            {
                cout << -1;
            }
            if (i < n - 1)
            {
                cout << " ";
            }
        }
        cout << endl;
    }

    return 0;
}